﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dice 
{
    class DeluxeDice : Dice
    {
        protected uint[] numbers = new uint[6];
        private Random random;
        protected int sum = 0;

        //default constructor 
        public DeluxeDice()
        {
            value = 1;
            random = new Random(
                  int.Parse(Guid.NewGuid().ToString().Substring(0, 8), System.Globalization.NumberStyles.HexNumber));
        }

        //overloaded constructor 
        public DeluxeDice(byte startValue) : base(startValue) // base - refers to the main/primary class constructor as well, it can refer to the method too. 
        {

        }

        public new void Roll() // new - hides the inherted method.
        {
           // base.Roll();

            GenerateStatistics(base.Roll());

            //return convert.tobyte(random.next(1, 7));
        }


        //Get Method
        public uint[] GetNumbers() { return this.numbers; }

        public new void Draw()
        {
            Console.WriteLine("\n");
            Console.WriteLine("DeluxeDice - default constructor");
            Console.WriteLine("\n");
            Console.WriteLine("*****");
            Console.WriteLine("**" + value + "**");
            Console.WriteLine("*****");
            Console.WriteLine("\n");


        }

        protected void GenerateStatistics(byte value)
        {
            switch (value)
            {
                case 1:
                    numbers[0]++;
                    sum += value;
                    break;

                case 2:
                    numbers[1]++;
                    sum += value;

                    break;


                case 3:
                    numbers[2]++;
                    sum += value;

                    break;


                case 4:
                    numbers[3]++;
                    sum += value;

                    break;


                case 5:
                    numbers[4]++;
                    sum += value;

                    break;


                case 6:
                    numbers[5]++;
                    sum += value;

                    break;


                default:
                    Console.WriteLine("Dice Face Value Error\n");
                    break;
            }
            

        }

        public void OutputStatistics()
        {
            int number = 1;

            foreach (int key in numbers)
            {
                Console.Write("Number " + number + ": ");
                Console.Write("\t\t" + key);
                Console.Write("\n\n");
                number++;
                sum += key;
            }

            Console.WriteLine("\n");
            Console.WriteLine("Sum all numbers: \t" + sum);
            Console.WriteLine("\n");
        }

       
    }
}
