﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dice
{
    class Dice
    {
        private Random random; // Random - A random class thats used to create random numbers. (pseudo-random).
        protected byte value;

        //default constructor 
        public Dice()
        {
            value = 1; 
            random =  new Random (
                  int.Parse(Guid.NewGuid().ToString().Substring(0, 8), System.Globalization.NumberStyles.HexNumber)); //Guid - stands for Globally unique identifier, a unique reference number used as an identifier in computer software.
        }

        //overloaded constructor 
        public Dice(byte startValue)
        {

           Validate(startValue);
            random = new Random(
                  int.Parse(Guid.NewGuid().ToString().Substring(0, 8), System.Globalization.NumberStyles.HexNumber)); //ToString - Converts a 'type' to a string. 
        }

        // int.Parse - Converts the string representation of a number to its signed integer equivalent.

        public byte Roll()
        {
            return Convert.ToByte(random.Next(1, 7)); // Convert - An method that lets us convert one 'type' to a different 'type'
        } 


        //Get Method
        public byte GetValue() { return value; }

        public void Draw()
        {
            Console.WriteLine("\n");  
            Console.WriteLine("Dice - default constructor");
            Console.WriteLine("\n");
            Console.WriteLine("*****");
            Console.WriteLine("**" + value + "**");
            Console.WriteLine("*****");

        }

        public void Validate(int startValue)
        {
            if (startValue > 0 && startValue < 7)
            {
                this.value = Convert.ToByte(startValue); // this - refers to the property of the object that cold this method.
            }

        }

        
    }
}
