﻿//Anton Antonenko 
//    March 25, 2016



using System;                       // using - refers to the built in libraries that we importing from c#.
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dice
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.ForegroundColor = ConsoleColor.White;  //Console - The console window object, that lets us see what we output and input. 
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Clear();

            Console.WriteLine("\n");

            Console.WriteLine("\t Anton Antonenko");
            Console.WriteLine("\n");


            DeluxeDice d2 = new DeluxeDice(9);

            Dice d3 = new Dice();

            DeluxeDice d4 = new DeluxeDice();

            d3.Roll();
            d4.Roll();

            d3.Draw();
            d4.Draw();

            for (double i=0; i<6000000; i++)
            {

                d2.Roll();


            }


            d2.OutputStatistics();

            d2.GetNumbers();
  

            }
        }
    }

// I like this code more, i wish the other assignments were more like it (different)
// than just rewiting the c++ code in java. I enjoyed the new twist and turns on c#,
// and all in all doing something new other than building a character (even though it
// was very helpful and practical for the understanding of objects).
// I feel this one is more readable than java, i dont know , i might sound baised, 
// but it either c++ / c# or Visual Studio , that makes me feel more like a developer
// when im writing code comapred to java.
// It to early to say what I like about C#, other than I DO LIKE IT, 
// i feel like i scratched just the surface with C# , wish we did more graphic stuff
// with it and not just console windows (i guess ill have to wait till next semester or 
// ill bet it to it).
// Nothing to dislike about it honestly, i feel like it pretty bendable and readable 
// for my taste. 
// Regarding the dice classes, they were pretty easy ,the instructions brake down was
// very helpful.